package com.maychat.app.data

import io.github.jan.supabase.auth.OtpType
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.auth.status.SessionStatus
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.postgrest.rpc
import io.github.jan.supabase.realtime.PostgresAction
import io.github.jan.supabase.realtime.RealtimeChannel
import io.github.jan.supabase.realtime.broadcastFlow
import io.github.jan.supabase.realtime.channel
import io.github.jan.supabase.realtime.postgresChangeFlow
import io.github.jan.supabase.realtime.realtime
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.time.OffsetDateTime

// The only place in the app that talks to Supabase.
// Screens call these functions; they never use the Supabase client directly.
object ChatRepository {

    const val PAGE_SIZE = 30

    private val supabase get() = SupabaseProvider.client
    private val json = Json { ignoreUnknownKeys = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // ------------------------------------------------------------------
    // Accounts
    // ------------------------------------------------------------------

    // Tells the app whether someone is logged in. The session is stored on
    // the phone, so the user stays logged in after closing the app.
    val sessionStatus: StateFlow<SessionStatus>
        get() = supabase.auth.sessionStatus

    fun currentUserId(): String? = supabase.auth.currentUserOrNull()?.id

    suspend fun isUsernameAvailable(username: String): Boolean {
        val result = supabase.postgrest.rpc(
            "username_available",
            buildJsonObject { put("p_username", username) },
        )
        return result.data.trim() == "true"
    }

    // Asks the database whether an account with this email exists
    // (see supabase_migration_04_email_check.sql).
    suspend fun isEmailRegistered(email: String): Boolean {
        val result = supabase.postgrest.rpc(
            "email_registered",
            buildJsonObject { put("p_email", email) },
        )
        return result.data.trim() == "true"
    }

    // Creates the account. The database creates the profile in the same step
    // (see handle_new_user in supabase_schema.sql).
    suspend fun signUp(email: String, password: String, username: String, displayName: String) {
        supabase.auth.signUpWith(Email) {
            this.email = email
            this.password = password
            data = buildJsonObject {
                put("username", username)
                put("display_name", displayName)
            }
        }
    }

    suspend fun signIn(email: String, password: String) {
        supabase.auth.signInWith(Email) {
            this.email = email
            this.password = password
        }
    }

    suspend fun signOut() {
        // Free the account for other devices (does nothing if this device
        // is not the one holding it).
        attempt {
            supabase.postgrest.rpc("release_session", buildJsonObject { put("p_device", deviceId) })
        }
        // This phone must stop receiving notifications for this account.
        attempt {
            supabase.postgrest.rpc("unregister_push_token", buildJsonObject { put("p_device", deviceId) })
        }
        stopRealtime()
        supabase.auth.signOut()
    }

    // ------------------------------------------------------------------
    // One device at a time (see supabase_migration_05_single_device.sql)
    // ------------------------------------------------------------------

    // Set once when the app starts (see MayChatApp).
    var deviceId: String = ""

    private val _authNotice = MutableStateFlow<String?>(null)

    // A message for the login screen, for example why the user was signed out.
    val authNotice: StateFlow<String?> = _authNotice.asStateFlow()

    fun clearAuthNotice() {
        _authNotice.value = null
    }

    // True if this device now holds the account. False if another device
    // is using the account right now.
    suspend fun claimSession(): Boolean {
        val result = supabase.postgrest.rpc(
            "claim_session",
            buildJsonObject { put("p_device", deviceId) },
        )
        return result.data.trim() == "true"
    }

    // Tells the server where to send this account's notifications
    // (see supabase_migration_06_push.sql).
    suspend fun registerPushToken(token: String) {
        supabase.postgrest.rpc(
            "register_push_token",
            buildJsonObject {
                put("p_device", deviceId)
                put("p_token", token)
            },
        )
    }

    // Signs out and tells the login screen why.
    suspend fun signOutWithNotice(message: String) {
        _authNotice.value = message
        attempt { signOut() }
    }

    // ------------------------------------------------------------------
    // Profiles
    // ------------------------------------------------------------------

    suspend fun loadProfile(userId: String): Profile? =
        supabase.postgrest.from("profiles")
            .select { filter { eq("id", userId) } }
            .decodeList<Profile>()
            .firstOrNull()

    // Finds users whose username starts with the typed text (max 20 results).
    suspend fun searchUsers(query: String, myId: String): List<Profile> {
        val clean = query.trim().lowercase().removePrefix("@")
            .filter { it.isLetterOrDigit() || it == '_' }
        if (clean.isEmpty()) return emptyList()
        return supabase.postgrest.from("profiles")
            .select {
                filter {
                    like("username", "$clean%")
                    neq("id", myId)
                }
                order("username", Order.ASCENDING)
                limit(20L)
            }
            .decodeList<Profile>()
    }

    suspend fun loadProfiles(ids: List<String>): List<Profile> {
        if (ids.isEmpty()) return emptyList()
        return supabase.postgrest.from("profiles")
            .select { filter { isIn("id", ids) } }
            .decodeList<Profile>()
    }

    // Records "I was active just now" with the server's clock
    // (see supabase_migration_08_last_seen.sql).
    suspend fun touchLastSeen() {
        supabase.postgrest.rpc("touch_last_seen")
    }

    // Same, for moments when the screen is going away and nothing can wait.
    fun touchLastSeenInBackground() {
        scope.launch { attempt { touchLastSeen() } }
    }

    // ------------------------------------------------------------------
    // Friends and blocking
    // The security rules only return rows that involve me. All changes go
    // through database functions that check who is calling.
    // ------------------------------------------------------------------

    suspend fun loadFriendships(): List<Friendship> =
        supabase.postgrest.from("friendships")
            .select { limit(500L) }
            .decodeList<Friendship>()

    suspend fun loadBlockedIds(): List<String> =
        supabase.postgrest.from("blocks")
            .select { limit(500L) }
            .decodeList<Block>()
            .map { it.blockedId }

    suspend fun sendFriendRequest(otherId: String) {
        supabase.postgrest.rpc("send_friend_request", buildJsonObject { put("p_other", otherId) })
    }

    suspend fun respondFriendRequest(otherId: String, accept: Boolean) {
        supabase.postgrest.rpc(
            "respond_friend_request",
            buildJsonObject {
                put("p_other", otherId)
                put("p_accept", accept)
            },
        )
    }

    suspend fun removeFriend(otherId: String) {
        supabase.postgrest.rpc("remove_friend", buildJsonObject { put("p_other", otherId) })
    }

    suspend fun blockUser(otherId: String) {
        supabase.postgrest.rpc("block_user", buildJsonObject { put("p_other", otherId) })
    }

    suspend fun unblockUser(otherId: String) {
        supabase.postgrest.rpc("unblock_user", buildJsonObject { put("p_other", otherId) })
    }

    // ------------------------------------------------------------------
    // Conversations
    // ------------------------------------------------------------------

    // Returns the id of my conversation with this user (created on first use).
    suspend fun openConversation(otherUserId: String): String {
        val result = supabase.postgrest.rpc(
            "get_or_create_conversation",
            buildJsonObject { put("p_other_user", otherUserId) },
        )
        return result.data.trim().trim('"')
    }

    // The security rules only return conversations I am a member of.
    suspend fun loadConversations(myId: String): List<ConversationItem> {
        val conversations = supabase.postgrest.from("conversations")
            .select { limit(100L) }
            .decodeList<Conversation>()
        if (conversations.isEmpty()) return emptyList()

        val otherIds = conversations.map { if (it.userA == myId) it.userB else it.userA }.distinct()
        val profiles = supabase.postgrest.from("profiles")
            .select { filter { isIn("id", otherIds) } }
            .decodeList<Profile>()
            .associateBy { it.id }

        return conversations
            .mapNotNull { c ->
                val otherId = if (c.userA == myId) c.userB else c.userA
                profiles[otherId]?.let { ConversationItem(c, it) }
            }
            .sortedByDescending { toEpochMillis(it.conversation.lastMessageAt ?: it.conversation.createdAt) }
    }

    // How many unread messages I have in each conversation
    // (see supabase_migration_07_unread.sql). Conversations with none are absent.
    suspend fun loadUnreadCounts(): Map<String, Int> =
        supabase.postgrest.rpc("unread_counts")
            .decodeList<UnreadCount>()
            .associate { it.conversationId to it.unread }

    // ------------------------------------------------------------------
    // Messages
    // ------------------------------------------------------------------

    // ------------------------------------------------------------------
    // My settings per conversation: pinned, muted, deleted on my side
    // (see supabase_migration_16_prefs_calls.sql)
    // ------------------------------------------------------------------

    // Conversation id -> the moment up to which I deleted it on my side.
    // Kept here so every query for messages can leave the older ones out.
    @Volatile
    private var clearedAt: Map<String, String> = emptyMap()

    // In the "...Z" form, so the value contains no "+" sign.
    private fun clearedUtc(conversationId: String): String? =
        clearedAt[conversationId]?.let {
            runCatching { OffsetDateTime.parse(it).toInstant().toString() }.getOrNull()
        }

    suspend fun loadConversationPrefs(): Map<String, ConversationPref> {
        val list = supabase.postgrest.from("conversation_prefs")
            .select()
            .decodeList<ConversationPref>()
        clearedAt = list.mapNotNull { pref -> pref.clearedAt?.let { pref.conversationId to it } }.toMap()
        return list.associateBy { it.conversationId }
    }

    // pinned / muted: null leaves the setting as it is.
    // clear = true deletes the conversation on my side.
    suspend fun setConversationPref(
        conversationId: String,
        pinned: Boolean? = null,
        muted: Boolean? = null,
        clear: Boolean = false,
    ) {
        supabase.postgrest.rpc(
            "set_conversation_pref",
            buildJsonObject {
                put("p_conversation", conversationId)
                put("p_pinned", pinned)
                put("p_muted", muted)
                put("p_clear", clear)
            },
        )
        attempt { loadConversationPrefs() }
    }

    // ------------------------------------------------------------------
    // Account settings
    // ------------------------------------------------------------------

    // True when I switched message notifications off.
    suspend fun loadMuteMessages(): Boolean =
        supabase.postgrest.from("user_settings")
            .select()
            .decodeList<UserSettings>()
            .firstOrNull()
            ?.muteMessages ?: false

    suspend fun setMuteMessages(muted: Boolean) {
        supabase.postgrest.rpc("set_mute_messages", buildJsonObject { put("p_muted", muted) })
    }

    // "Forgot password", step 1: the server emails a code to this address.
    suspend fun sendPasswordResetCode(email: String) {
        supabase.auth.resetPasswordForEmail(email)
    }

    // Step 2: the code proves the email is mine (this also logs me in),
    // then the new password is saved. Runs to the end even when the login
    // screen disappears halfway because the login already succeeded.
    suspend fun resetPasswordWithCode(email: String, code: String, newPassword: String) {
        withContext(NonCancellable) {
            supabase.auth.verifyEmailOtp(type = OtpType.Email.RECOVERY, email = email, token = code)
            supabase.auth.updateUser { password = newPassword }
        }
    }

    suspend fun changePassword(newPassword: String) {
        supabase.auth.updateUser { password = newPassword }
    }

    // ------------------------------------------------------------------
    // Call history
    // ------------------------------------------------------------------

    // Second path for the "set up a call" messages, through the database
    // (supabase_migration_20_call_signals.sql).
    suspend fun sendCallSignal(toUserId: String, payload: JsonObject) {
        supabase.postgrest.rpc(
            "send_call_signal",
            buildJsonObject {
                put("p_to", toUserId)
                put("p_payload", payload)
            },
        )
    }

    // Fetches and removes the call messages waiting for me.
    suspend fun takeCallSignals(): List<JsonObject> =
        supabase.postgrest.rpc("take_call_signals").decodeList<JsonObject>()

    // Relay servers for calls (supabase_migration_19_call_servers.sql).
    // An empty list means "direct connection only", as before.
    suspend fun loadCallServers(): List<CallServer> =
        supabase.postgrest.from("call_servers").select().decodeList<CallServer>()

    // Written by the caller's phone when a call starts. Returns the id of
    // the new history row.
    suspend fun logCallStart(calleeId: String): String =
        supabase.postgrest.rpc("log_call_start", buildJsonObject { put("p_callee", calleeId) })
            .data.trim().trim('"')

    // status: answered, missed, declined, cancelled or failed.
    suspend fun logCallEnd(callId: String, status: String, durationSeconds: Int) {
        supabase.postgrest.rpc(
            "log_call_end",
            buildJsonObject {
                put("p_call", callId)
                put("p_status", status)
                put("p_duration", durationSeconds)
            },
        )
    }

    // My newest 100 calls, made and received, with the other person's profile.
    suspend fun loadCalls(myId: String): List<CallItem> {
        val calls = supabase.postgrest.from("calls")
            .select {
                order("started_at", Order.DESCENDING)
                limit(100L)
            }
            .decodeList<CallLog>()
        if (calls.isEmpty()) return emptyList()

        val otherIds = calls.map { if (it.callerId == myId) it.calleeId else it.callerId }.distinct()
        val profiles = loadProfiles(otherIds).associateBy { it.id }
        return calls.mapNotNull { call ->
            val outgoing = call.callerId == myId
            profiles[if (outgoing) call.calleeId else call.callerId]?.let { CallItem(call, it, outgoing) }
        }
    }

    // ------------------------------------------------------------------
    // Group chats (see supabase_migration_21_groups.sql)
    // ------------------------------------------------------------------

    // The security rules only return groups I am a member of.
    suspend fun loadGroups(): List<Group> =
        supabase.postgrest.from("groups").select().decodeList<Group>()

    // null when the group does not exist or I am not (or no longer) a member.
    suspend fun loadGroup(groupId: String): Group? =
        supabase.postgrest.from("groups")
            .select { filter { eq("id", groupId) } }
            .decodeList<Group>()
            .firstOrNull()

    suspend fun loadGroupMembers(groupId: String): List<Profile> {
        val ids = supabase.postgrest.from("group_members")
            .select { filter { eq("group_id", groupId) } }
            .decodeList<GroupMember>()
            .map { it.userId }
        return loadProfiles(ids)
    }

    suspend fun loadGroupUnreadCounts(): Map<String, Int> =
        supabase.postgrest.rpc("group_unread_counts")
            .decodeList<GroupUnread>()
            .associate { it.groupId to it.unread }

    // Returns the id of the new group.
    suspend fun createGroup(name: String, memberIds: List<String>): String =
        supabase.postgrest.rpc(
            "create_group",
            buildJsonObject {
                put("p_name", name)
                put("p_members", buildJsonArray { memberIds.forEach { add(it) } })
            },
        ).data.trim().trim('"')

    suspend fun addGroupMembers(groupId: String, memberIds: List<String>) {
        supabase.postgrest.rpc(
            "add_group_members",
            buildJsonObject {
                put("p_group", groupId)
                put("p_members", buildJsonArray { memberIds.forEach { add(it) } })
            },
        )
    }

    suspend fun removeGroupMember(groupId: String, userId: String) {
        supabase.postgrest.rpc(
            "remove_group_member",
            buildJsonObject {
                put("p_group", groupId)
                put("p_user", userId)
            },
        )
    }

    suspend fun leaveGroup(groupId: String) {
        supabase.postgrest.rpc("leave_group", buildJsonObject { put("p_group", groupId) })
    }

    suspend fun renameGroup(groupId: String, name: String) {
        supabase.postgrest.rpc(
            "rename_group",
            buildJsonObject {
                put("p_group", groupId)
                put("p_name", name)
            },
        )
    }

    suspend fun markGroupRead(groupId: String) {
        supabase.postgrest.rpc("mark_group_read", buildJsonObject { put("p_group", groupId) })
    }

    // One page of group messages, newest first. Pass the time of the oldest
    // message already shown to get the page before it.
    suspend fun loadGroupMessages(groupId: String, before: String? = null, limit: Int = PAGE_SIZE): List<GroupMessage> {
        val beforeUtc = before?.let {
            runCatching { OffsetDateTime.parse(it).toInstant().toString() }.getOrNull()
        }
        // Messages up to the moment I deleted the history on my side are left out.
        val cleared = groupClearedUtc(groupId)
        return supabase.postgrest.from("group_messages")
            .select {
                filter {
                    eq("group_id", groupId)
                    if (beforeUtc != null) lt("created_at", beforeUtc)
                    if (cleared != null) gt("created_at", cleared)
                }
                order("created_at", Order.DESCENDING)
                limit(limit.toLong())
            }
            .decodeList<GroupMessage>()
    }

    suspend fun sendGroupMessage(message: NewGroupMessage) {
        supabase.postgrest.from("group_messages").insert(message)
    }

    // ------------------------------------------------------------------
    // Group chats: the features of one-to-one chats
    // (see supabase_migration_22_group_features.sql)
    // ------------------------------------------------------------------

    // Group id -> the moment up to which I deleted its history on my side.
    @Volatile
    private var groupClearedAt: Map<String, String> = emptyMap()

    private fun groupClearedUtc(groupId: String): String? =
        groupClearedAt[groupId]?.let {
            runCatching { OffsetDateTime.parse(it).toInstant().toString() }.getOrNull()
        }

    // My settings per group: pinned at the top, muted, history deleted.
    suspend fun loadGroupPrefs(): Map<String, GroupPref> {
        val list = supabase.postgrest.from("group_prefs")
            .select()
            .decodeList<GroupPref>()
        groupClearedAt = list.mapNotNull { pref -> pref.clearedAt?.let { pref.groupId to it } }.toMap()
        return list.associateBy { it.groupId }
    }

    // pinned / muted: null leaves the setting as it is.
    // clear = true deletes the history of the group on my side.
    suspend fun setGroupPref(
        groupId: String,
        pinned: Boolean? = null,
        muted: Boolean? = null,
        clear: Boolean = false,
    ) {
        supabase.postgrest.rpc(
            "set_group_pref",
            buildJsonObject {
                put("p_group", groupId)
                put("p_pinned", pinned)
                put("p_muted", muted)
                put("p_clear", clear)
            },
        )
        attempt { loadGroupPrefs() }
    }

    // The rows of the member list, with up to when each member has read.
    suspend fun loadGroupMemberRows(groupId: String): List<GroupMember> =
        supabase.postgrest.from("group_members")
            .select { filter { eq("group_id", groupId) } }
            .decodeList<GroupMember>()

    suspend fun sendGroupReply(message: NewGroupReplyMessage) {
        supabase.postgrest.from("group_messages").insert(message)
    }

    suspend fun recallGroupMessage(messageId: String) {
        supabase.postgrest.rpc("recall_group_message", buildJsonObject { put("p_message", messageId) })
    }

    suspend fun hideGroupMessage(messageId: String) {
        supabase.postgrest.rpc("hide_group_message", buildJsonObject { put("p_message", messageId) })
    }

    suspend fun loadHiddenGroupMessageIds(groupId: String): Set<String> =
        supabase.postgrest.rpc(
            "hidden_group_message_ids",
            buildJsonObject { put("p_group", groupId) },
        ).decodeList<String>().toSet()

    // emoji = null removes my reaction.
    suspend fun setGroupReaction(messageId: String, emoji: String?) {
        supabase.postgrest.rpc(
            "set_group_reaction",
            buildJsonObject {
                put("p_message", messageId)
                put("p_emoji", emoji ?: "")
            },
        )
    }

    suspend fun loadGroupReactions(groupId: String): List<Reaction> =
        supabase.postgrest.rpc(
            "group_reactions",
            buildJsonObject { put("p_group", groupId) },
        ).decodeList<Reaction>()

    suspend fun loadGroupPinnedMessage(groupId: String): PinnedMessage? =
        supabase.postgrest.rpc(
            "group_pinned_message",
            buildJsonObject { put("p_group", groupId) },
        ).decodeList<PinnedMessage>().firstOrNull()
            // A message I deleted on my side is not shown as pinned to me.
            ?.takeIf { pin ->
                val cleared = groupClearedAt[groupId]
                cleared == null || toEpochMillis(pin.createdAt) > toEpochMillis(cleared)
            }

    suspend fun pinGroupMessage(messageId: String) {
        supabase.postgrest.rpc("pin_group_message", buildJsonObject { put("p_message", messageId) })
    }

    suspend fun unpinGroupMessage(groupId: String) {
        supabase.postgrest.rpc("unpin_group_message", buildJsonObject { put("p_group", groupId) })
    }

    // value = null removes the background.
    suspend fun setGroupWallpaper(groupId: String, value: String?) {
        supabase.postgrest.rpc(
            "set_group_wallpaper",
            buildJsonObject {
                put("p_group", groupId)
                put("p_value", value ?: "")
            },
        )
    }

    // Text messages of one group that contain the given words, accents and
    // upper/lower case ignored (newest first, at most SEARCH_LIMIT).
    suspend fun searchGroupMessages(groupId: String, query: String): List<GroupMessage> {
        val clean = query.trim().replace("\\", "").replace("%", "").replace("_", " ")
        if (clean.length < 2) return emptyList()
        return supabase.postgrest.rpc(
            "search_group_messages",
            buildJsonObject {
                put("p_group", groupId)
                put("p_query", clean)
                put("p_after", groupClearedUtc(groupId))
            },
        ).decodeList<GroupMessage>()
    }

    // Newest pictures or files of one group, for the group information
    // screen. kind is "image" or "file".
    suspend fun loadGroupSharedMedia(groupId: String, kind: String, limit: Int): List<GroupMessage> {
        val cleared = groupClearedUtc(groupId)
        return supabase.postgrest.from("group_messages")
            .select {
                filter {
                    eq("group_id", groupId)
                    eq("kind", kind)
                    if (cleared != null) gt("created_at", cleared)
                }
                order("created_at", Order.DESCENDING)
                limit(limit.toLong())
            }
            .decodeList<GroupMessage>()
    }

    // Loads one page of messages, newest first. Pass the time of the oldest
    // message already shown to get the page before it.
    suspend fun loadMessages(
        conversationId: String,
        before: String? = null,
        limit: Int = PAGE_SIZE,
    ): List<Message> {
        // Convert to the "...Z" form so the value contains no "+" sign.
        val beforeUtc = before?.let {
            runCatching { OffsetDateTime.parse(it).toInstant().toString() }.getOrNull()
        }
        val cleared = clearedUtc(conversationId)
        return supabase.postgrest.from("messages")
            .select {
                filter {
                    eq("conversation_id", conversationId)
                    if (beforeUtc != null) lt("created_at", beforeUtc)
                    if (cleared != null) gt("created_at", cleared)
                }
                order("created_at", Order.DESCENDING)
                limit(limit.toLong())
            }
            .decodeList<Message>()
    }

    suspend fun sendMessage(conversationId: String, text: String): Message =
        supabase.postgrest.from("messages")
            .insert(NewMessage(conversationId, text)) { select() }
            .decodeSingle<Message>()

    // ------------------------------------------------------------------
    // Images and voice messages (Supabase Storage, private bucket)
    // ------------------------------------------------------------------

    const val MEDIA_BUCKET = "chat-media"

    // path looks like "<conversation id>/<random name>.jpg"
    suspend fun uploadMedia(path: String, bytes: ByteArray) {
        supabase.storage.from(MEDIA_BUCKET).upload(path, bytes)
    }

    suspend fun downloadMedia(path: String): ByteArray =
        supabase.storage.from(MEDIA_BUCKET).downloadAuthenticated(path)

    suspend fun sendMediaMessage(
        conversationId: String,
        kind: String,
        mediaPath: String,
        label: String,
        durationMs: Int?,
    ): Message =
        supabase.postgrest.from("messages")
            .insert(NewMediaMessage(conversationId, label, kind, mediaPath, durationMs)) { select() }
            .decodeSingle<Message>()

    // ------------------------------------------------------------------
    // Avatar and profile (see supabase_migration_09_profile_recall.sql)
    // ------------------------------------------------------------------

    const val AVATAR_BUCKET = "avatars"

    // path looks like "<my user id>/<random name>.jpg"
    suspend fun uploadAvatar(path: String, bytes: ByteArray) {
        supabase.storage.from(AVATAR_BUCKET).upload(path, bytes)
    }

    suspend fun downloadAvatar(path: String): ByteArray =
        supabase.storage.from(AVATAR_BUCKET).downloadAuthenticated(path)

    // avatarPath: null keeps the current avatar, "" removes it.
    suspend fun updateMyProfile(displayName: String, avatarPath: String?) {
        supabase.postgrest.rpc(
            "update_my_profile",
            buildJsonObject {
                put("p_display_name", displayName)
                put("p_avatar_path", avatarPath)
            },
        )
    }

    // ------------------------------------------------------------------
    // Recall (for both people) and hide (on my side only)
    // ------------------------------------------------------------------

    // Removes files from the storage to free space. Best effort: if it fails
    // (for example migration 18 was not run) the file just stays there.
    suspend fun deleteMedia(path: String) {
        attempt { supabase.storage.from(MEDIA_BUCKET).delete(listOf(path)) }
    }

    suspend fun deleteAvatar(path: String) {
        attempt { supabase.storage.from(AVATAR_BUCKET).delete(listOf(path)) }
    }

    suspend fun recallMessage(messageId: String) {
        supabase.postgrest.rpc("recall_message", buildJsonObject { put("p_message", messageId) })
    }

    suspend fun hideMessage(messageId: String) {
        supabase.postgrest.rpc("hide_message", buildJsonObject { put("p_message", messageId) })
    }

    suspend fun loadHiddenMessageIds(conversationId: String): Set<String> =
        supabase.postgrest.rpc(
            "hidden_message_ids",
            buildJsonObject { put("p_conversation", conversationId) },
        ).decodeList<String>().toSet()

    // ------------------------------------------------------------------
    // Reply (quote) and reactions (see supabase_migration_10_...sql)
    // ------------------------------------------------------------------

    suspend fun sendReply(
        conversationId: String,
        text: String,
        replyToId: String,
        replyPreview: String,
        replySenderId: String,
    ): Message =
        supabase.postgrest.from("messages")
            .insert(NewReplyMessage(conversationId, text, replyToId, replyPreview, replySenderId)) { select() }
            .decodeSingle<Message>()

    // A message carrying any file (see supabase_migration_12_files.sql).
    suspend fun sendFileMessage(
        conversationId: String,
        mediaPath: String,
        label: String,
        fileName: String,
        fileSize: Int,
    ): Message =
        supabase.postgrest.from("messages")
            .insert(NewFileMessage(conversationId, label, "file", mediaPath, fileName, fileSize)) { select() }
            .decodeSingle<Message>()

    // A picture or voice message that answers another message.
    suspend fun sendMediaReply(
        conversationId: String,
        kind: String,
        mediaPath: String,
        label: String,
        durationMs: Int?,
        replyToId: String,
        replyPreview: String,
        replySenderId: String,
    ): Message =
        supabase.postgrest.from("messages")
            .insert(
                NewMediaReplyMessage(
                    conversationId, label, kind, mediaPath, durationMs,
                    replyToId, replyPreview, replySenderId,
                ),
            ) { select() }
            .decodeSingle<Message>()

    // ------------------------------------------------------------------
    // Chat background shared by both people (supabase_migration_13)
    // ------------------------------------------------------------------

    // Returns the background value, or null when there is none.
    suspend fun loadWallpaper(conversationId: String): String? =
        supabase.postgrest.from("conversations")
            .select { filter { eq("id", conversationId) } }
            .decodeList<Conversation>()
            .firstOrNull()
            ?.wallpaper

    // value = null removes the background.
    suspend fun setWallpaper(conversationId: String, value: String?) {
        supabase.postgrest.rpc(
            "set_wallpaper",
            buildJsonObject {
                put("p_conversation", conversationId)
                put("p_value", value ?: "")
            },
        )
    }

    // ------------------------------------------------------------------
    // Pinned message (see supabase_migration_11_pin.sql)
    // ------------------------------------------------------------------

    suspend fun loadPinnedMessage(conversationId: String): PinnedMessage? =
        supabase.postgrest.rpc(
            "pinned_message",
            buildJsonObject { put("p_conversation", conversationId) },
        ).decodeList<PinnedMessage>().firstOrNull()
            // A message I deleted on my side is not shown as pinned to me.
            ?.takeIf { pin ->
                val cleared = clearedAt[conversationId]
                cleared == null || toEpochMillis(pin.createdAt) > toEpochMillis(cleared)
            }

    suspend fun pinMessage(messageId: String) {
        supabase.postgrest.rpc("pin_message", buildJsonObject { put("p_message", messageId) })
    }

    suspend fun unpinMessage(conversationId: String) {
        supabase.postgrest.rpc("unpin_message", buildJsonObject { put("p_conversation", conversationId) })
    }

    // emoji = null removes my reaction.
    suspend fun setReaction(messageId: String, emoji: String?) {
        supabase.postgrest.rpc(
            "set_reaction",
            buildJsonObject {
                put("p_message", messageId)
                put("p_emoji", emoji ?: "")
            },
        )
    }

    suspend fun loadReactions(conversationId: String): List<Reaction> =
        supabase.postgrest.rpc(
            "conversation_reactions",
            buildJsonObject { put("p_conversation", conversationId) },
        ).decodeList<Reaction>()

    // The most results one search returns. The screen shows "300+" when
    // this many were found, because there may be more.
    const val SEARCH_LIMIT = 300

    // Text messages of one conversation that contain the given words
    // (newest first, at most SEARCH_LIMIT). Upper and lower case do not matter.
    suspend fun searchMessages(conversationId: String, query: String): List<Message> {
        // "%" and "_" have a special meaning in the search pattern.
        val clean = query.trim().replace("\\", "").replace("%", "").replace("_", " ")
        if (clean.length < 2) return emptyList()
        val cleared = clearedUtc(conversationId)

        // First choice: the search on the server that ignores Vietnamese
        // accents (supabase_migration_17_search.sql). If that function is
        // not there, fall back to the exact search used before.
        val folded = attempt {
            supabase.postgrest.rpc(
                "search_messages",
                buildJsonObject {
                    put("p_conversation", conversationId)
                    put("p_query", clean)
                    put("p_after", cleared)
                },
            ).decodeList<Message>()
        }.getOrNull()
        if (folded != null) return folded

        return supabase.postgrest.from("messages")
            .select {
                filter {
                    eq("conversation_id", conversationId)
                    eq("kind", "text")
                    ilike("content", "%$clean%")
                    if (cleared != null) gt("created_at", cleared)
                }
                order("created_at", Order.DESCENDING)
                limit(SEARCH_LIMIT.toLong())
            }
            .decodeList<Message>()
            .filter { it.recalledAt == null }
    }

    // Tells the server "my app has received everything sent to me so far",
    // which turns "Đã gửi" into "Đã nhận" on the senders' phones.
    // (see supabase_migration_15_delivered.sql)
    suspend fun markDelivered() {
        supabase.postgrest.rpc("mark_delivered")
    }

    // Newest pictures or files of one conversation, for the Options screen.
    // kind is "image" or "file".
    suspend fun loadSharedMedia(conversationId: String, kind: String, limit: Int): List<Message> {
        val cleared = clearedUtc(conversationId)
        return supabase.postgrest.from("messages")
            .select {
                filter {
                    eq("conversation_id", conversationId)
                    eq("kind", kind)
                    if (cleared != null) gt("created_at", cleared)
                }
                order("created_at", Order.DESCENDING)
                limit(limit.toLong())
            }
            .decodeList<Message>()
    }

    suspend fun markConversationRead(conversationId: String) {
        supabase.postgrest.rpc(
            "mark_conversation_read",
            buildJsonObject { put("p_conversation", conversationId) },
        )
    }

    // ------------------------------------------------------------------
    // Realtime: new messages, read receipts, who is online
    // ------------------------------------------------------------------

    private val _messageEvents = MutableSharedFlow<Message>(extraBufferCapacity = 64)

    // Every new or changed message I am allowed to see arrives here.
    val messageEvents: SharedFlow<Message> = _messageEvents.asSharedFlow()

    private val _friendEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 16)

    // Fires when a friend request or friendship that involves me changes.
    val friendEvents: SharedFlow<Unit> = _friendEvents.asSharedFlow()

    private val _reactionEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 16)

    // Fires when a reaction is added, changed or removed in one of my chats.
    val reactionEvents: SharedFlow<Unit> = _reactionEvents.asSharedFlow()

    private val _onlineUsers = MutableStateFlow<Set<String>>(emptySet())

    // Ids of users who currently have the app open.
    val onlineUsers: StateFlow<Set<String>> = _onlineUsers.asStateFlow()

    private val _connectionCount = MutableStateFlow(0)

    // Goes up by one each time the live connection is (re)established.
    // Screens reload their data when this changes, to catch up on anything
    // that happened while the phone was offline.
    val connectionCount: StateFlow<Int> = _connectionCount.asStateFlow()

    private var realtimeJob: Job? = null
    private var dbChannel: RealtimeChannel? = null
    private var presenceChannel: RealtimeChannel? = null
    private val onlineCounts = HashMap<String, Int>()

    // Makes sure two restarts never run at the same time.
    private val realtimeMutex = Mutex()

    suspend fun startRealtime(myId: String) = realtimeMutex.withLock {
        closeRealtime()
        openRealtime(myId)
    }

    suspend fun stopRealtime() = realtimeMutex.withLock {
        closeRealtime()
    }

    private fun openRealtime(myId: String) {

        // Channel 1: database changes of the "messages" and "friendships" tables. The server only
        // sends rows this user may read (Row Level Security).
        val db = supabase.channel("messages-$myId-${System.currentTimeMillis()}")
        // Channel 2: one shared channel where every open app announces itself.
        val presence = supabase.channel("online-users")
        dbChannel = db
        presenceChannel = presence

        realtimeJob = scope.launch {
            val changes = db.postgresChangeFlow<PostgresAction>(schema = "public") {
                table = "messages"
            }
            launch {
                changes.collect { action ->
                    val record: JsonObject? = when (action) {
                        is PostgresAction.Insert -> action.record
                        is PostgresAction.Update -> action.record
                        else -> null
                    }
                    if (record != null) {
                        runCatching { json.decodeFromJsonElement(Message.serializer(), record) }
                            .onSuccess { _messageEvents.emit(it) }
                    }
                }
            }

            val friendChanges = db.postgresChangeFlow<PostgresAction>(schema = "public") {
                table = "friendships"
            }
            launch {
                friendChanges.collect { _friendEvents.emit(Unit) }
            }

            val reactionChanges = db.postgresChangeFlow<PostgresAction>(schema = "public") {
                table = "message_reactions"
            }
            launch {
                reactionChanges.collect { _reactionEvents.emit(Unit) }
            }

            val presenceChanges = presence.presenceChangeFlow()
            launch {
                presenceChanges.collect { action ->
                    synchronized(onlineCounts) {
                        action.joins.values.forEach { p ->
                            val id = p.state["user_id"]?.jsonPrimitive?.contentOrNull ?: return@forEach
                            onlineCounts[id] = (onlineCounts[id] ?: 0) + 1
                        }
                        action.leaves.values.forEach { p ->
                            val id = p.state["user_id"]?.jsonPrimitive?.contentOrNull ?: return@forEach
                            val left = (onlineCounts[id] ?: 0) - 1
                            if (left <= 0) onlineCounts.remove(id) else onlineCounts[id] = left
                        }
                        _onlineUsers.value = onlineCounts.keys.toSet()
                    }
                }
            }

            // Announce "I am online" every time the presence channel is joined,
            // including after an automatic reconnect.
            launch {
                presence.status.collect { status ->
                    if (status == RealtimeChannel.Status.SUBSCRIBED) {
                        runCatching { presence.track(buildJsonObject { put("user_id", myId) }) }
                    }
                }
            }
            launch {
                db.status.collect { status ->
                    if (status == RealtimeChannel.Status.SUBSCRIBED) {
                        _connectionCount.value = _connectionCount.value + 1
                    }
                }
            }

            // Give the collectors above a moment to start listening, then join.
            delay(300)
            launch { joinWithRetry(db) }
            launch { joinWithRetry(presence) }

            // Watchdog: phones often drop the live connection (screen off,
            // Wi-Fi to mobile data, battery saver). If a channel stays
            // disconnected for about 20 seconds, throw both channels away
            // and build fresh ones.
            launch {
                var badChecks = 0
                while (isActive) {
                    delay(7_000)
                    val healthy = db.status.value == RealtimeChannel.Status.SUBSCRIBED &&
                        presence.status.value == RealtimeChannel.Status.SUBSCRIBED
                    if (healthy) {
                        badChecks = 0
                    } else {
                        badChecks++
                        if (badChecks >= 3) {
                            // Started from the outer scope because the restart
                            // cancels this very coroutine.
                            scope.launch { startRealtime(myId) }
                            break
                        }
                    }
                }
            }
        }
    }

    // Joins a channel. If the phone is offline right now, tries again every
    // few seconds. After the first successful join, the library reconnects
    // by itself when the network drops and comes back.
    private suspend fun joinWithRetry(channel: RealtimeChannel) {
        while (currentCoroutineContext().isActive &&
            channel.status.value != RealtimeChannel.Status.SUBSCRIBED
        ) {
            try {
                withTimeoutOrNull(10_000) { channel.subscribe(blockUntilSubscribed = true) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                // Offline or server not reachable: fall through and retry.
            }
            if (channel.status.value != RealtimeChannel.Status.SUBSCRIBED) delay(3_000)
        }
    }

    private suspend fun closeRealtime() {
        realtimeJob?.cancel()
        realtimeJob = null
        dbChannel?.let { ch -> runCatching { supabase.realtime.removeChannel(ch) } }
        presenceChannel?.let { ch -> runCatching { supabase.realtime.removeChannel(ch) } }
        dbChannel = null
        presenceChannel = null
        synchronized(onlineCounts) { onlineCounts.clear() }
        _onlineUsers.value = emptySet()
    }

    // ------------------------------------------------------------------
    // "Is typing" indicator
    // Uses Realtime Broadcast: small messages that go straight from one
    // phone to the other and are never stored in the database.
    // ------------------------------------------------------------------

    private val typingChannels = HashMap<String, RealtimeChannel>()

    // Listens for "the other person is typing" in one conversation and calls
    // onTyping each time. Runs until the caller is cancelled (chat closed).
    suspend fun listenTyping(conversationId: String, myId: String, onTyping: () -> Unit) {
        val channel = supabase.channel("typing-$conversationId")
        synchronized(typingChannels) { typingChannels[conversationId] = channel }
        try {
            coroutineScope {
                val events = channel.broadcastFlow<JsonObject>(event = "typing")
                launch {
                    events.collect { payload ->
                        val from = payload["user_id"]?.jsonPrimitive?.contentOrNull
                        if (from != null && from != myId) onTyping()
                    }
                }
                delay(300)
                joinWithRetry(channel)
            }
        } finally {
            synchronized(typingChannels) {
                if (typingChannels[conversationId] === channel) typingChannels.remove(conversationId)
            }
            withContext(NonCancellable) {
                runCatching { supabase.realtime.removeChannel(channel) }
            }
        }
    }

    // Same as listenTyping, for a GROUP: tells WHO is typing (their user
    // id). channelId is the id of the group.
    suspend fun listenTypingWho(channelId: String, myId: String, onTyping: (String) -> Unit) {
        val channel = supabase.channel("typing-$channelId")
        synchronized(typingChannels) { typingChannels[channelId] = channel }
        try {
            coroutineScope {
                val events = channel.broadcastFlow<JsonObject>(event = "typing")
                launch {
                    events.collect { payload ->
                        val from = payload["user_id"]?.jsonPrimitive?.contentOrNull
                        if (from != null && from != myId) onTyping(from)
                    }
                }
                delay(300)
                joinWithRetry(channel)
            }
        } finally {
            synchronized(typingChannels) {
                if (typingChannels[channelId] === channel) typingChannels.remove(channelId)
            }
            withContext(NonCancellable) {
                runCatching { supabase.realtime.removeChannel(channel) }
            }
        }
    }

    // Tells the other person "I am typing". Does nothing when offline.
    suspend fun sendTyping(conversationId: String, myId: String) {
        val channel = synchronized(typingChannels) { typingChannels[conversationId] } ?: return
        if (channel.status.value != RealtimeChannel.Status.SUBSCRIBED) return
        try {
            channel.broadcast(event = "typing", message = buildJsonObject { put("user_id", myId) })
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            // Not important enough to show an error.
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    fun toEpochMillis(timestamp: String?): Long =
        if (timestamp == null) 0L
        else runCatching { OffsetDateTime.parse(timestamp).toInstant().toEpochMilli() }.getOrDefault(0L)
}
