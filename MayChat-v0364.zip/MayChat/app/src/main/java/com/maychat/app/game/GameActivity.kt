package com.maychat.app.game

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.webkit.WebViewAssetLoader
import com.maychat.app.data.ChatRepository
import com.maychat.app.data.attempt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.time.OffsetDateTime

// =====================================================================
// The farm game (tab "Game"), in its own screen, always sideways.
//
// The game is a web page packaged in the app (assets/game/: farm.html,
// hoithao.html and the pictures in img/), so it opens without
// downloading anything. The page asks the app for everything that needs
// the account through window.MayChatGame:
//   call(id, method, args)  -> the app answers with window.__mc.done(id, answer)
//   setRipeAlarm(ms)        -> a notification when the next crop is ripe
//   close()                 -> back to MayChat
// The farm itself is kept on the server (supabase_migration_31_farm.sql).
// =====================================================================
class GameActivity : ComponentActivity() {

    companion object {
        private const val PREFS = "maychat_game"
        private const val PAGE = "https://appassets.androidplatform.net/assets/game/farm.html"

        // "Mới" on the Game tab until the game was opened once.
        fun isNew(context: Context): Boolean =
            !context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("opened", false)

        fun open(context: Context, roomId: String? = null) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("opened", true).apply()
            val intent = Intent(context, GameActivity::class.java)
            if (roomId != null) {
                // "Vào" on an invite card: straight into that Hội thao room
                intent.putExtra(EXTRA_ROOM, roomId)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            context.startActivity(intent)
        }

        const val EXTRA_ROOM = "room"
        private val ROOM_ID = Regex("^[0-9a-fA-F-]{36}$")
    }

    private var web: WebView? = null
    private val json = Json { ignoreUnknownKeys = true }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Only for a logged-in account.
        if (ChatRepository.currentUserId() == null) {
            finish()
            return
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideBars()

        // The packaged files are served as https://appassets.androidplatform.net/assets/...
        // so the farm page and the Hội thao page inside it are one website.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        val view = WebView(this)
        view.setBackgroundColor(0xFFCDEFFC.toInt())
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // Hội thao remembers its settings
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
        }
        view.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            // The game never leaves its own pages.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != "appassets.androidplatform.net"
        }
        view.addJavascriptInterface(Bridge(), "MayChatGame")
        setContentView(view)
        web = view

        // Back: first closes what is open in the game (a sheet, Hội thao), then leaves.
        onBackPressedDispatcher.addCallback(this) {
            val page = web
            if (page == null) {
                finish()
            } else {
                page.evaluateJavascript("(window.__mc && window.__mc.back) ? window.__mc.back() : false") { answer ->
                    if (answer != "true") finish()
                }
            }
        }
        view.loadUrl(pageFor(intent))
        listenForInvites()
    }

    // A friend invites me to a Hội thao room while I am in the game: the
    // invite is shown inside the game ("Vào" / "Để sau"). New invite
    // messages come from the live connection that MayChat already has.
    private val seenInvites = HashSet<String>()

    private fun listenForInvites() {
        val me = ChatRepository.currentUserId() ?: return
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                ChatRepository.messageEvents.collect { m ->
                    if (m.kind != "game" || m.senderId == me || m.readAt != null || !seenInvites.add(m.id)) return@collect
                    val room = m.extra?.takeIf { ROOM_ID.matches(it) } ?: return@collect
                    // only fresh invites (not an old message that was changed)
                    val sentAt = runCatching { OffsetDateTime.parse(m.createdAt).toInstant().toEpochMilli() }.getOrNull()
                    if (sentAt != null && kotlin.math.abs(System.currentTimeMillis() - sentAt) > 10 * 60_000) return@collect
                    val name = attempt { ChatRepository.loadProfile(m.senderId) }.getOrNull()?.displayName ?: "Bạn bè"
                    val invite = buildJsonObject {
                        put("room", room)
                        put("name", name)
                        put("text", m.content)
                    }
                    web?.evaluateJavascript("window.__mc && window.__mc.invite && window.__mc.invite($invite)", null)
                }
            }
        }
    }

    private fun pageFor(intent: Intent?): String {
        val room = intent?.getStringExtra(EXTRA_ROOM)?.takeIf { ROOM_ID.matches(it) }
        return if (room != null) "$PAGE?room=$room" else PAGE
    }

    // The game is already open and an invite card was tapped.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val room = intent.getStringExtra(EXTRA_ROOM)?.takeIf { ROOM_ID.matches(it) } ?: return
        web?.evaluateJavascript("window.__mc && window.__mc.joinRoom && window.__mc.joinRoom(${JSONObject.quote(room)})", null)
    }

    private fun hideBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    // Not on screen: the game stops drawing (no battery used).
    override fun onPause() {
        web?.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web?.onResume()
        // Time has passed: the page asks the server for the farm again.
        web?.evaluateJavascript("window.__mc && window.__mc.resume && window.__mc.resume()", null)
    }

    override fun onDestroy() {
        // leaving the game also leaves the live channel of a Hội thao room
        kotlinx.coroutines.CoroutineScope(Dispatchers.Default).launch { ChatRepository.leaveGameRoom() }
        web?.apply {
            removeJavascriptInterface("MayChatGame")
            destroy()
        }
        web = null
        super.onDestroy()
    }

    private inner class Bridge {
        // Called by the page on a background thread; answers on the screen's thread.
        @JavascriptInterface
        fun call(id: Int, method: String, args: String) {
            lifecycleScope.launch {
                val answer = answer(method, args)
                web?.evaluateJavascript("window.__mc && window.__mc.done($id, ${JSONObject.quote(answer)})", null)
            }
        }

        @JavascriptInterface
        fun setRipeAlarm(ms: String) {
            FarmAlarm.set(applicationContext, ms.toLongOrNull() ?: 0L)
        }

        // One message to the other phones of the Hội thao room (no answer).
        @JavascriptInterface
        fun rtSend(message: String) {
            ChatRepository.sendGameMessage(message)
        }

        @JavascriptInterface
        fun close() {
            runOnUiThread { finish() }
        }
    }

    // {"ok":true,"data":...} or {"ok":false,"error":"..."}
    private suspend fun answer(method: String, args: String): String {
        val result = attempt {
            if (method == "profile") {
                profile()
            } else if (method == "friends") {
                // name, online, and the MayChat picture (small) of each friend
                val list = ChatRepository.gameFriendList()
                val pics = coroutineScope { list.map { (p, _) -> async { avatarOf(p.avatarPath) } }.awaitAll() }
                buildJsonArray {
                    list.forEachIndexed { i, (p, online) ->
                        add(
                            buildJsonObject {
                                put("id", p.id)
                                put("name", p.displayName)
                                put("online", online)
                                put("avatar", pics[i])
                            },
                        )
                    }
                }.toString()
            } else if (method == "avatars") {
                // the pictures of the people in a Hội thao room: {"<user id>": "data:..."}
                val ids = runCatching { json.parseToJsonElement(args).jsonObject["ids"]?.jsonArray?.map { it.jsonPrimitive.content } }
                    .getOrNull().orEmpty().filter { ROOM_ID.matches(it) }.take(12)
                val people = if (ids.isEmpty()) emptyList() else ChatRepository.loadProfiles(ids)
                val pics = coroutineScope { people.map { p -> async { avatarOf(p.avatarPath) } }.awaitAll() }
                buildJsonObject { people.forEachIndexed { i, p -> put(p.id, pics[i]) } }.toString()
            } else if (method == "rt_join") {
                val room = runCatching { json.parseToJsonElement(args).jsonObject["room"]?.jsonPrimitive?.content }.getOrNull()
                    ?.takeIf { ROOM_ID.matches(it) } ?: error("bad_room")
                ChatRepository.joinGameRoom(room) { message ->
                    runOnUiThread {
                        web?.evaluateJavascript("window.__mc && window.__mc.rt && window.__mc.rt($message)", null)
                    }
                }
                "true"
            } else if (method == "rt_leave") {
                ChatRepository.leaveGameRoom()
                "true"
            } else {
                val given = runCatching { json.parseToJsonElement(args).jsonObject }.getOrNull() ?: JsonObject(emptyMap())
                // {"name": ...} from the page -> p_name for the SQL function
                val params = buildJsonObject { given.forEach { (key, value) -> put("p_$key", value) } }
                ChatRepository.farmCall(method, params)
            }
        }
        return result.fold(
            onSuccess = { data -> "{\"ok\":true,\"data\":${data.ifBlank { "null" }}}" },
            onFailure = { e -> "{\"ok\":false,\"error\":${JSONObject.quote(e.message ?: "error")}}" },
        )
    }

    // Small pictures already made, by their place in Storage.
    private val avatarCache = HashMap<String, String?>()

    private suspend fun avatarOf(path: String?): String? {
        if (path.isNullOrBlank()) return null
        synchronized(avatarCache) { if (avatarCache.containsKey(path)) return avatarCache[path] }
        val pic = attempt { smallPicture(ChatRepository.downloadAvatar(path)) }.getOrNull()
        synchronized(avatarCache) { avatarCache[path] = pic }
        return pic
    }

    // My name and avatar (small, as a picture the page can show directly).
    private suspend fun profile(): String {
        val me = ChatRepository.currentUserId() ?: return "null"
        val profile = attempt { ChatRepository.loadProfile(me) }.getOrNull()
        val avatar = profile?.avatarPath?.takeIf { it.isNotBlank() }?.let { path ->
            attempt { smallPicture(ChatRepository.downloadAvatar(path)) }.getOrNull()
        }
        return buildJsonObject {
            put("id", me)
            put("name", profile?.displayName ?: "")
            put("avatar", avatar)
        }.toString()
    }

    private suspend fun smallPicture(bytes: ByteArray): String? = withContext(Dispatchers.Default) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 128 && bounds.outHeight / (sample * 2) >= 128) sample *= 2
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return@withContext null
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
        bitmap.recycle()
        "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
